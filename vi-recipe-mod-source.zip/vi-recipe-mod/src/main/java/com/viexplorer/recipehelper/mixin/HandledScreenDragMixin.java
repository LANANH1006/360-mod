package com.viexplorer.recipehelper.mixin;

import com.viexplorer.recipehelper.client.SmithingPanel;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Cho phép kéo chuột để xoay mô hình 3D trên bàn nâng cấp. require = 0: nếu không tìm thấy hàm thì bỏ qua. */
@Mixin(HandledScreen.class)
public abstract class HandledScreenDragMixin {

    @Inject(method = "mouseDragged", at = @At("HEAD"), cancellable = true, require = 0)
    private void vi$mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY,
                                 CallbackInfoReturnable<Boolean> cir) {
        if (SmithingPanel.drag(deltaX, deltaY)) {
            cir.setReturnValue(true);
        }
    }
}
