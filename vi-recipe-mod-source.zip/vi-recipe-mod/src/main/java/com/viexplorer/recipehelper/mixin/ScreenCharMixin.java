package com.viexplorer.recipehelper.mixin;

import com.viexplorer.recipehelper.client.BrewingPanel;
import net.minecraft.client.gui.screen.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Chuyển ký tự gõ vào sang ô tìm kiếm của giàn chế thuốc (game không có sự kiện riêng cho việc này). */
@Mixin(Screen.class)
public abstract class ScreenCharMixin {

    @Inject(method = "charTyped", at = @At("HEAD"), cancellable = true)
    private void vi$charTyped(char chr, int modifiers, CallbackInfoReturnable<Boolean> cir) {
        if (BrewingPanel.charTyped(chr)) {
            cir.setReturnValue(true);
        }
    }
}
