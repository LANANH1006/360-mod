package com.viexplorer.recipehelper.mixin;

import com.viexplorer.recipehelper.client.BrewingPanel;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Khi đang gõ tìm kiếm, chặn phím tắt của game (ví dụ phím E đóng giao diện),
 * để có thể gõ các chữ như "nhanh nhẹn" mà không bị đóng màn hình.
 */
@Mixin(HandledScreen.class)
public abstract class HandledScreenKeyMixin {

    @Inject(method = "keyPressed", at = @At("HEAD"), cancellable = true)
    private void vi$keyPressed(int keyCode, int scanCode, int modifiers, CallbackInfoReturnable<Boolean> cir) {
        if (BrewingPanel.keyPressed(keyCode)) {
            cir.setReturnValue(true);
        }
    }
}
