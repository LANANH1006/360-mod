# Vi Recipe Helper (Minecraft 1.21.4 Fabric)

Mod phía client, giao diện tiếng Việt:

- **Giàn chế thuốc (Brewing Stand):** bảng bên phải có ô tìm kiếm ở trên, danh sách công thức cuộn bên dưới. Mỗi công thức hiển thị bằng icon 2D: `[thuốc gốc] + [nguyên liệu] = [thuốc kết quả]`.
  - Gõ có dấu hoặc không dấu đều được, ví dụ `thuốc sức mạnh` hoặc `thuoc suc manh`.
  - Có thể tìm theo tên nguyên liệu, ví dụ `bụi phát sáng` hoặc `glowstone`.
  - Lăn chuột để cuộn, rê chuột vào một dòng để xem chi tiết.
- **Bàn phù phép (Enchanting Table):** đặt vật phẩm vào ô bên trái, bảng bên phải liệt kê tất cả phép có thể áp dụng cho vật phẩm đó, kèm cấp tối đa.
- **Bàn nâng cấp (Smithing Table):** bảng bên phải hiện 3 ô nguyên liệu bằng icon 2D và khung xem trước 3D của vật phẩm kết quả. Kéo chuột trái trong khung để xoay 360 độ.

## Yêu cầu

- Minecraft 1.21.4
- Fabric Loader 0.16.9 trở lên
- Fabric API 0.119.4+1.21.4

## Cách lấy file mod (không cần cài Java/Gradle trên máy)

1. Tạo repo mới trên GitHub, upload toàn bộ thư mục này (nhớ có thư mục `.github`).
2. Vào tab **Actions** → chọn **Build mod** → **Run workflow** (hoặc chỉ cần push code).
3. Khi build xong, mở lần chạy đó, tải artifact **vi-recipe-helper**. Trong đó có file `.jar`.
4. Bỏ file `.jar` vào thư mục `mods` cùng với Fabric API.

## Build trên máy (tùy chọn)

Cần JDK 21 và Gradle 8.12:

```
gradle build
```

File mod nằm trong `build/libs/`.

## Ghi chú

- Phiên bản Fabric trong `gradle.properties` được viết theo phiên bản 1.21.4 đã biết. Nếu build báo không tìm thấy `yarn_mappings` hoặc `fabric_version`, kiểm tra lại tại https://fabricmc.net/develop/ và sửa dòng tương ứng.
- Danh sách công thức pha thuốc trong `BrewingData.java` là các công thức vanilla đã biết (gồm Splash, Lingering, Long, Strong), viết từ trí nhớ nên có thể thiếu hoặc sai vài dòng. Có thể bổ sung bằng cách thêm dòng `add(...)`.
- Bàn nâng cấp: hiện tại chỉ xem trước kết quả khi đã đặt đủ nguyên liệu. Chưa có danh sách tất cả công thức nâng cấp.
- Chưa có: cờ (loom), vật phẩm từ mod khác, và dự đoán 3 lựa chọn ngẫu nhiên của bàn phù phép (không đoán trước được vì phụ thuộc seed).
- Mod chưa được compile và kiểm thử trong game. Nếu build hoặc game báo lỗi, gửi log cho người phát triển để sửa.
